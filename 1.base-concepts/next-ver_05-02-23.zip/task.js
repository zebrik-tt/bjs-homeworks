"use strict"
function solveEquation(a, b, c) {
  let arr = [];
  
  return arr;
}

function calculateTotalMortgage(percent, contribution, amount, countMonths) {
  
}